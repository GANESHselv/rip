<!DOCTYPE html> 
<html translate="no" data-dpr="1" style="font-size: 40px;"><head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="robots" content="noindex,nofollow"><meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" name="viewport"><meta name="google-site-verification"><head><style data-styles="">ion-icon{visibility:hidden}.hydrated{visibility:inherit}</style><meta http-equiv="refresh" content="3; url='/myhome#/'" /><meta charset="utf-8"><html translate="no" data-dpr="1" style="font-size: 40px;"><head><meta charset="utf-8"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta name="robots" content="noindex,nofollow"><meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" name="viewport"><meta name="google-site-verification"><link rel="icon" href="./ico.png">
<meta name="google" content="notranslate">
<meta name="robots" content="noindex,nofollow">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

<link rel="manifest">
<title>91 Club</title><link href="https://91clubin.in/css/chunk-009b4c4c.8f338b77.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-01c025bd.1667b8ce.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-02d640c5.16079f26.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-048ffacc.922dbd6d.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-04d9e7e8.f2872521.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-050df13e.f5550c00.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-05d395a8.27167ad5.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-085e8808.15897d4c.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0adadd62.d96be006.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0b09369e.c66921c5.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0b0fb3cd.72cfd6ac.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0c41b112.95faab95.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0cd68ae6.df92961c.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0db7c1f6.5739eac5.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0e10c9c3.583c8acb.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0ecd09c6.87d344f2.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0efec584.970e752d.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0f044119.7bad5bf5.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-0fd8d9ae.1d9debf8.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-145d4a1e.465d2bc1.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-16f496dc.94dfae31.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-1b7444a2.92a31d6b.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-21037111.d4a7e2a5.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-21c81672.44e6c68a.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-23008c6a.4d6883d8.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-25e66eaa.c71493da.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-264008c4.bb60e1c2.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-2670eec6.40e6c360.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-27122907.90238e28.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-278d59ee.e7249e90.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-2a8bfa06.b779eb7d.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-2b3f542c.64d2f89e.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-2b64aefc.ece41114.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-2c48d9e6.5807d9e5.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-2c510426.9caeb1a6.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-2d123fa7.112a8fd8.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-2de9240a.19e6b622.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-30bd42b6.4346da8a.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-3233bd0f.7551ce0e.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-3265b096.56fa0105.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-3315d54e.9f52a246.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-3334e104.cbcafb9c.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-339c81a2.1812c088.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-3484bcc5.30d7756a.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-38251dc0.5d14ab44.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-39ce87f8.00d81b8f.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-3a5c97d3.13207cfe.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-3cc70fec.2e8de1d9.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-3fcf4ae6.04566cc0.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-41bcbf7a.2abfdfeb.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-41cc83f4.519fd919.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-41d45588.c598f077.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-422c3438.72ff4de0.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-44abccc0.3d756849.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-44d5df02.6d92e0bb.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-45e4acaa.08a21094.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-45fa2dd4.5545b206.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-461a1710.e2706d03.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-467e3165.1aa205de.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-495c0a68.d31174e6.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-4db0772a.fd229f9d.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-4eb90e66.0b2a38a2.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-4f411f1c.30a25410.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-53841b4e.c3c35a59.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-548e69f3.bdb86635.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-574a6948.327ff7af.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-5d17b1cb.cfda8ce1.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-5d18b3d6.9452af2f.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-5e578388.2aa8f2ab.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-5fadbd2a.9529f5b5.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-5fcdc3a0.d037c096.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-5ff9b99b.5e7b3eb7.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-60cc3413.18202013.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-61d0c116.ef0e8c84.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-63bb93b0.cf2f814d.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-644ff02f.9f48865a.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-64cdf166.976ed132.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-66d5b656.7b0be418.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-6712d1aa.99b41fef.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-680ea8cc.af122ef6.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-685aa3e6.70510f63.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-6b43bd10.5b7d20a2.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-6ea1c8ab.5d055e78.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-71dcadf2.ec6e09e7.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-7293d7fb.cef69bd8.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-72f01a9a.5a06efac.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-738292a9.40de55be.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-75071d1a.f1719299.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-769894e4.d83dca0e.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-7ad1fcf0.8cc2c21c.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-7cba53d2.d60eaa4b.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-7f5a45e2.709b22ad.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-862854c0.b0596219.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-90f8a4d8.45f356ca.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-943f7cea.5763c16b.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-9ca7d0dc.0f968705.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-a718bce8.6c66860a.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-ab61d66a.44da8a56.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-ae1ed794.e4fd2944.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-afb3fabc.8b080c82.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-b3a478b0.c6a9ccda.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-b4b2c9bc.ed6cb6bd.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-b70405a6.39dca3b3.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-b9e72770.58208d71.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-ba192fcc.9a5c3f09.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-bd05a822.f0757d49.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-c0d15508.e8e9c998.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-c7d4e1ca.7a7a2286.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-cc5799d2.9e80b6d6.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-ccd4fcae.88e701d4.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-da973c7a.af085279.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-dc017ec6.8183a423.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-e635d700.3bce96ee.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-edde0e28.c55780b1.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-ef29c82e.275bde9f.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-faa8abe2.eb4c7660.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-fd347064.2e191ec7.css" rel="prefetch"><link href="https://91clubin.in/css/chunk-fdbeb1dc.a3cf84fb.css" rel="prefetch"><link href="js/chunk-009b4c4c.81df4a8f.js" rel="prefetch"><link href="js/chunk-01c025bd.2bbadfca.js" rel="prefetch"><link href="js/chunk-02d640c5.9189a9d0.js" rel="prefetch"><link href="js/chunk-048ffacc.d690c148.js" rel="prefetch"><link href="js/chunk-04d9e7e8.8766abcc.js" rel="prefetch"><link href="js/chunk-050df13e.2d0dc101.js" rel="prefetch"><link href="js/chunk-05d395a8.e4569df4.js" rel="prefetch"><link href="js/chunk-085e8808.64fc9b14.js" rel="prefetch"><link href="js/chunk-0adadd62.4b5ba311.js" rel="prefetch"><link href="js/chunk-0b09369e.57726062.js" rel="prefetch"><link href="js/chunk-0b0fb3cd.c83506a3.js" rel="prefetch"><link href="js/chunk-0c41b112.fa94f7da.js" rel="prefetch"><link href="js/chunk-0cd68ae6.17e067d1.js" rel="prefetch"><link href="js/chunk-0db7c1f6.4515ced8.js" rel="prefetch"><link href="js/chunk-0e10c9c3.75104bcd.js" rel="prefetch"><link href="js/chunk-0ecd09c6.9f9ac37c.js" rel="prefetch"><link href="js/chunk-0efec584.e91e8008.js" rel="prefetch"><link href="js/chunk-0f044119.f0ac31ff.js" rel="prefetch"><link href="js/chunk-0fd8d9ae.a4162172.js" rel="prefetch"><link href="js/chunk-145d4a1e.57ba1582.js" rel="prefetch"><link href="js/chunk-16f496dc.d55a52f4.js" rel="prefetch"><link href="js/chunk-1b7444a2.29a409ab.js" rel="prefetch"><link href="js/chunk-21037111.13a32279.js" rel="prefetch"><link href="js/chunk-21c81672.c5a0d4a0.js" rel="prefetch"><link href="js/chunk-23008c6a.a08ad5fb.js" rel="prefetch"><link href="js/chunk-25e66eaa.6880430a.js" rel="prefetch"><link href="js/chunk-264008c4.0a976a88.js" rel="prefetch"><link href="js/chunk-2670eec6.bac7bcfb.js" rel="prefetch"><link href="js/chunk-27122907.962c3c1a.js" rel="prefetch"><link href="js/chunk-278d59ee.b886cec7.js" rel="prefetch"><link href="js/chunk-2a8bfa06.89d564dc.js" rel="prefetch"><link href="js/chunk-2b3f542c.b4f101d7.js" rel="prefetch"><link href="js/chunk-2b64aefc.ae34c1d8.js" rel="prefetch"><link href="js/chunk-2c48d9e6.4a8b99c4.js" rel="prefetch"><link href="js/chunk-2c510426.1cd67b0a.js" rel="prefetch"><link href="js/chunk-2d0c9b56.72a96010.js" rel="prefetch"><link href="js/chunk-2d123fa7.0a5ccdf9.js" rel="prefetch"><link href="js/chunk-2d216257.3986ae5c.js" rel="prefetch"><link href="js/chunk-2d21d0c2.2bf78577.js" rel="prefetch"><link href="js/chunk-2de9240a.b6b52653.js" rel="prefetch"><link href="js/chunk-30bd42b6.d2b1c701.js" rel="prefetch"><link href="js/chunk-3233bd0f.adf23e38.js" rel="prefetch"><link href="js/chunk-3265b096.1cb56161.js" rel="prefetch"><link href="js/chunk-3315d54e.5e4b4d71.js" rel="prefetch"><link href="js/chunk-3334e104.6c943722.js" rel="prefetch"><link href="js/chunk-339c81a2.527f7f1d.js" rel="prefetch"><link href="js/chunk-3484bcc5.24eeed4c.js" rel="prefetch"><link href="js/chunk-38251dc0.e9bddedb.js" rel="prefetch"><link href="js/chunk-39ce87f8.9cb1fd38.js" rel="prefetch"><link href="js/chunk-3a5c97d3.8cf6cb80.js" rel="prefetch"><link href="js/chunk-3cc70fec.6d7aee14.js" rel="prefetch"><link href="js/chunk-3fcf4ae6.dc042102.js" rel="prefetch"><link href="js/chunk-41bcbf7a.20d00d31.js" rel="prefetch"><link href="js/chunk-41cc83f4.f4fa2a37.js" rel="prefetch"><link href="js/chunk-41d45588.04692e36.js" rel="prefetch"><link href="js/chunk-422c3438.363bc718.js" rel="prefetch"><link href="js/chunk-44abccc0.41a2c857.js" rel="prefetch"><link href="js/chunk-44d5df02.e08cba75.js" rel="prefetch"><link href="js/chunk-45e4acaa.068c3bae.js" rel="prefetch"><link href="js/chunk-45fa2dd4.b1313658.js" rel="prefetch"><link href="js/chunk-461a1710.918d0775.js" rel="prefetch"><link href="js/chunk-467e3165.cccc832f.js" rel="prefetch"><link href="js/chunk-495c0a68.ffd25065.js" rel="prefetch"><link href="js/chunk-4db0772a.9eb385bc.js" rel="prefetch"><link href="js/chunk-4eb90e66.e742df04.js" rel="prefetch"><link href="js/chunk-4f411f1c.6bd8f28b.js" rel="prefetch"><link href="js/chunk-53841b4e.718e6063.js" rel="prefetch"><link href="js/chunk-548e69f3.55243944.js" rel="prefetch"><link href="js/chunk-574a6948.a70bb147.js" rel="prefetch"><link href="js/chunk-5d17b1cb.378c7068.js" rel="prefetch"><link href="js/chunk-5d18b3d6.0703b780.js" rel="prefetch"><link href="js/chunk-5e578388.3f14797b.js" rel="prefetch"><link href="js/chunk-5fadbd2a.fe692d30.js" rel="prefetch"><link href="js/chunk-5fcdc3a0.1e2d060c.js" rel="prefetch"><link href="js/chunk-5ff9b99b.4263d25f.js" rel="prefetch"><link href="js/chunk-60cc3413.35f07742.js" rel="prefetch"><link href="js/chunk-61d0c116.455fe424.js" rel="prefetch"><link href="js/chunk-63bb93b0.fed60a45.js" rel="prefetch"><link href="js/chunk-644ff02f.c5902659.js" rel="prefetch"><link href="js/chunk-64cdf166.ebde209e.js" rel="prefetch"><link href="js/chunk-66d5b656.04704f87.js" rel="prefetch"><link href="js/chunk-6712d1aa.8022b3b8.js" rel="prefetch"><link href="js/chunk-680ea8cc.10be9646.js" rel="prefetch"><link href="js/chunk-685aa3e6.694bc00c.js" rel="prefetch"><link href="js/chunk-6b43bd10.4c4e695f.js" rel="prefetch"><link href="js/chunk-6ea1c8ab.0d813840.js" rel="prefetch"><link href="js/chunk-71dcadf2.5734c50d.js" rel="prefetch"><link href="js/chunk-7293d7fb.09f7ed55.js" rel="prefetch"><link href="js/chunk-72f01a9a.f850d6ba.js" rel="prefetch"><link href="js/chunk-738292a9.d305a505.js" rel="prefetch"><link href="js/chunk-75071d1a.0902f509.js" rel="prefetch"><link href="js/chunk-769894e4.e1f41c39.js" rel="prefetch"><link href="js/chunk-7ad1fcf0.c0b3a684.js" rel="prefetch"><link href="js/chunk-7cba53d2.5a4e3099.js" rel="prefetch"><link href="js/chunk-7f5a45e2.7515903c.js" rel="prefetch"><link href="js/chunk-862854c0.cb6bef09.js" rel="prefetch"><link href="js/chunk-90f8a4d8.afe55541.js" rel="prefetch"><link href="js/chunk-943f7cea.1af9539d.js" rel="prefetch"><link href="js/chunk-9ca7d0dc.4baaefa8.js" rel="prefetch"><link href="js/chunk-a718bce8.45a55e03.js" rel="prefetch"><link href="js/chunk-ab61d66a.c634d68f.js" rel="prefetch"><link href="js/chunk-ae1ed794.1175f2bc.js" rel="prefetch"><link href="js/chunk-afb3fabc.3015e93f.js" rel="prefetch"><link href="js/chunk-b198f854.d9039cad.js" rel="prefetch"><link href="js/chunk-b3a478b0.a71765ee.js" rel="prefetch"><link href="js/chunk-b4b2c9bc.587a31e4.js" rel="prefetch"><link href="js/chunk-b70405a6.bb489671.js" rel="prefetch"><link href="js/chunk-b9e72770.2c01de84.js" rel="prefetch"><link href="js/chunk-ba192fcc.c0be3eb1.js" rel="prefetch"><link href="js/chunk-bd05a822.a51d2a16.js" rel="prefetch"><link href="js/chunk-c0d15508.8a782284.js" rel="prefetch"><link href="js/chunk-c7d4e1ca.37e3e9c7.js" rel="prefetch"><link href="js/chunk-cc5799d2.e67f86c5.js" rel="prefetch"><link href="js/chunk-ccd4fcae.d342cd62.js" rel="prefetch"><link href="js/chunk-da973c7a.510ed324.js" rel="prefetch"><link href="js/chunk-dc017ec6.641c818c.js" rel="prefetch"><link href="js/chunk-e635d700.71c7c36f.js" rel="prefetch"><link href="js/chunk-edde0e28.6a2f6e59.js" rel="prefetch"><link href="js/chunk-ef29c82e.eac85665.js" rel="prefetch"><link href="js/chunk-faa8abe2.b7e4e4a9.js" rel="prefetch"><link href="js/chunk-fd347064.46533541.js" rel="prefetch"><link href="js/chunk-fdbeb1dc.18f29ddc.js" rel="prefetch"><link href="https://91clubin.in/css/app.de1c8be3.css" rel="preload" as="style"><link href="https://91clubin.in/css/chunk-vendors.b521b44f.css" rel="preload" as="style"><link href="js/app.5320d06e.js" rel="preload" as="script"><link href="js/chunk-vendors.043d61fb.js" rel="preload" as="script"><link href="https://91clubin.in/css/chunk-vendors.b521b44f.css" rel="stylesheet"><link href="https://91clubin.in/css/app.de1c8be3.css" rel="stylesheet"><link rel="stylesheet" type="text/css" href="https://91clubin.in/css/chunk-943f7cea.5763c16b.css"><script charset="utf-8" src="js/chunk-943f7cea.1af9539d.js"></script></head>
<body style="font-size: 12px;"><noscript><strong>We're sorry but colorShopGame doesn't work properly without JavaScript enabled. Please enable it to continue.</strong></noscript><div id="app"><div data-v-377bc0d1="" style="background: #f54545;
    background-image: linear-gradient(90deg,#fe6868,#f54545);" class="mian"><div data-v-377bc0d1="" class="logo van-image"><img src="./Wonicon.png" class="van-image__img"></div><div data-v-377bc0d1="" style="background: #f54545;
    background-image: linear-gradient(90deg,#fe6868,#f54545);" class="mian1"><div data-v-377bc0d1="" class="logo1 van-image"><img src="./Wlogo.png" class="van-image__img"></div><div data-v-377bc0d1="" class="time c-row c-row-middle-center" id="countdowntimer" style="background-image: linear-gradient(90deg,#fff,#fff);
    font-size: .45333rem;
    font-weight:450;
    color: #f54545;
">3</div></div></div><script>window.onload = function () {
			let cfg  = JSON.parse(localStorage.getItem('clientCfg'));
			// console.log(cfg)
			if (cfg) {
				var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
				// var meta = document.querySelector("meta[name*='google-site-verification']") || document.createElement('meta');
				// meta.content = '是十四'
				link.type = 'image/x-icon';
				link.rel = 'shortcut icon';
				link.href = cfg.WebIco;//'http://47.56.7.183:5001/img/tatalogo.jpg';
				document.getElementsByTagName('head')[0].appendChild(link);
				// document.getElementsByTagName('head')[0].appendChild(meta);
				
				document.getElementsByTagName("title")[0].innerText = cfg.ProjectName;
			}
			document.addEventListener('touchstart', function (event) {
				if (event.touches.length > 1) {
					event.preventDefault();  //阻止元素的默认行为
				}
			}, {
				capture: false,
				passive: false,
				once: false
			});
			// document.addEventListener('touchmove', function (event) {
			// 	event.preventDefault();  //阻止元素的默认行为
			// }, {
			// 	passive: false,
			// });
		}</script><style>html,body{ height: 100%; width: 100%; background-color: #fff;padding: 0;margin: 0;}</style><script src="js/chunk-vendors.043d61fb.js"></script><script src="js/app.5320d06e.js"></script></body></html>
     <script type="text/javascript">
    var timeleft = 3;
    var downloadTimer = setInterval(function(){
    timeleft--;
    document.getElementById("countdowntimer").textContent = timeleft;
    if(timeleft <= 0)
        clearInterval(downloadTimer);
    },1000);
</script><script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
<script nomodule="" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>        <script>
                $.fn.center = function () {
  this.css("position","fixed");
  this.css("top", Math.max(0, (
    ($(window).height() - $(this).outerHeight()) / 2) + 
     $(window).scrollTop()) + "px"
  );
  this.css("left", Math.max(0, (
    ($(window).width() - $(this).outerWidth()) / 2) + 
     $(window).scrollLeft()) + "px"
  );
  return this;
}

$("#overlay").show();
$("#overlay-content").show().center();

setTimeout(function(){    
  $("#overlay").fadeOut();
}, 3000);
       </script>
     
      <script src="home/assets/js/jquery-3.4.1.min.js"></script> 
      <!-- Bootstrap--> 
      <script src="home/assets/js/popper.min.js"></script> 
      <script src="home/assets/js/bootstrap.min.js"></script> 
      <!-- Owl Carousel --> 
      <script src="home/assets/js/owl.carousel.min.js"></script> 
      <!-- Tween Max -->
      <script src="home/assets/js/tweenmax.js"></script> 
       <script>
  
	window.oncontextmenu = function () {
				return false;
			}
			$(document).keydown(function (event) {
				if (event.keyCode == 123) {
					return false;
				}
				else if ((event.ctrlKey && event.shiftKey && event.keyCode == 73) || (event.ctrlKey && event.shiftKey && event.keyCode == 74)) {
					return false;
				}
			});


//  document.onkeydown = function(e) {
//     if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 ||     e.keyCode === 117 || e.keycode === 17 || e.keycode === 85)) {
//         alert('Not Allowed');
//     }
//     return false;
// };

</script>      <!-- Main Js File --> 
        <script>
          const second = 1000,
         minute = second * 60,
         hour = minute * 60,
         day = hour * 24;
         
         let countDown = new Date('May 27, 2021 20:00:00').getTime(),
                           x = setInterval(function() {
                                             let now = new Date().getTime(),
                                             distance = now - countDown;
                                             document.getElementById('days').innerText = Math.floor(distance / (day)),
                                             document.getElementById('hours').innerText = Math.floor((distance % (day)) / (hour)),
                                             document.getElementById('minutes').innerText = Math.floor((distance % (hour)) / (minute)),
                                             document.getElementById('seconds').innerText = Math.floor((distance % (minute)) / second);
                                           }, second);
         
         var items = document.getElementsByClassName("fade-item");
         for (let i = 0; i < items.length; ++i) {
           fadeIn(items[i], i * 1000)
         }
         
         function fadeIn (item, delay) {
           setTimeout(() => {
             item.classList.add('fadein')
           }, delay)
         }
         $(document).ready(function(){
         
         $(".tabs-list li a").click(function(e){
          e.preventDefault();
         });
         
         $(".tabs-list li").click(function(){
          var tabid = $(this).find("a").attr("href");
          $(".tabs-list li,.tabs div.tab").removeClass("active");   // removing active class from tab
         
          $(".tab").hide();   // hiding open tab
          $(tabid).show();    // show tab
          $(this).addClass("active"); //  adding active class to clicked tab
         
         });
         
         });
         
         var vsOpts = {
         $slides: $('.v-slide'),
         $list: $('.v-slides'),
         $slides2: $('.v-slide2'),
         $list2: $('.v-slides2'),
         $slides3: $('.v-slide3'),
         $list3: $('.v-slides3'),
         $slides4: $('.v-slide4'),
         $list4: $('.v-slides4'),
         duration: 40,
         lineHeight: 50
         }
         
         var vSlide = new TimelineMax({
         paused: false,
         repeat: 1
         });
         
         var vSlide2 = new TimelineMax({
         paused: false,
         repeat: 1
         });
         
         var vSlide3 = new TimelineMax({
         paused: false,
         repeat: 1
         });
         
         var vSlide4 = new TimelineMax({
         paused: false,
         repeat: 1
         });
         
         vsOpts.$slides.each(function(i) {
         console.log('length : '+ vsOpts.$slides.length);
         vSlide.to(vsOpts.$list, vsOpts.duration / vsOpts.$slides.length, {
           y: i * -1 * 70,
           ease: Elastic.easeOut.config(1, 0.4)
         });
         });
         
         vSlide.play();
         
         vsOpts.$slides2.each(function(i) {
         console.log('length2 : '+ vsOpts.$slides2.length);
         vSlide2.to(vsOpts.$list2, vsOpts.duration / vsOpts.$slides2.length, {
           y: i * -1 * 70,
           ease: Elastic.easeOut.config(1, 0.4)
         });
         });
         
         vSlide2.play();
         
         vsOpts.$slides3.each(function(i) {
         console.log('length3 : '+ vsOpts.$slides3.length);
         vSlide3.to(vsOpts.$list3, vsOpts.duration / vsOpts.$slides3.length, {
           y: i * -1 * 70,
           ease: Elastic.easeOut.config(1, 0.4)
         });
         });
         
         vSlide3.play();
         
         vsOpts.$slides4.each(function(i) {
         console.log('length4 : '+ vsOpts.$slides4.length);
         vSlide4.to(vsOpts.$list4, vsOpts.duration / vsOpts.$slides4.length, {
           y: i * -1 * 70,
           ease: Elastic.easeOut.config(1, 0.4)
         });
         });
         
         vSlide4.play();
         
     
      </script><script>window.onload = function () {
			let cfg  = JSON.parse(localStorage.getItem('clientCfg'));
			// console.log(cfg)
			if (cfg) {
				var link = document.querySelector("link[rel*='icon']") || document.createElement('link');
				// var meta = document.querySelector("meta[name*='google-site-verification']") || document.createElement('meta');
				// meta.content = '是十四'
				link.type = 'image/x-icon';
				link.rel = 'shortcut icon';
				link.href = cfg.WebIco;//'http://47.56.7.183:5001/img/tatalogo.jpg';
				document.getElementsByTagName('head')[0].appendChild(link);
				// document.getElementsByTagName('head')[0].appendChild(meta);
				
				document.getElementsByTagName("title")[0].innerText = cfg.ProjectName;
			}
			document.addEventListener('touchstart', function (event) {
				if (event.touches.length > 1) {
					event.preventDefault();  //阻止元素的默认行为
				}
			}, {
				capture: false,
				passive: false,
				once: false
			});
			// document.addEventListener('touchmove', function (event) {
			// 	event.preventDefault();  //阻止元素的默认行为
			// }, {
			// 	passive: false,
			// });
		}</script><style>
 .float{ 
       z-index: 99;
    position: fixed;
    width: 46px;
    height: 46px;
    bottom: 120px;
    right: 5px;
    text-align: center;
}
.mian .logo[data-v-377bc0d1] {
    position: absolute;
    bottom: 45%;
    left: 50%;
    transform: translate(-50%);
    width: 70%;
}
.mian1 .logo1[data-v-377bc0d1] {
    position: absolute;
    bottom: 20%;
    left: 52%;
    transform: translate(-50%);
    width: 80%;
}
  .floattext {
    display: flex;
    background: #f90;
    color: #ffffff;
    padding: 7px 8px;
    font-size: 10px;
    width: fit-content;
    border-radius: 2px;
    height: 20px;
    line-height: 8px;
    margin-top: 50px;
    box-shadow: 0 0 6px;
}


.my-float{
	margin-top:22px;
}</style><style>html,body{ height: 100%; width: 100%; background-color: #9195a3;padding: 0;margin: 0;}</style><script src="js/chunk-vendors.043d61fb.js"></script><script src="js/app.8cf78f8d.js"></script></body></html>